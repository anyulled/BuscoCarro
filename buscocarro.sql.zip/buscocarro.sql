-- phpMyAdmin SQL Dump
-- version 3.3.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 26-07-2010 a las 07:47:28
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.2-1ubuntu4.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `buscocarro`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carros`
--

CREATE TABLE IF NOT EXISTS `carros` (
  `idCarro` int(11) NOT NULL AUTO_INCREMENT,
  `idMarca` int(11) DEFAULT NULL,
  `idModelo` int(11) DEFAULT NULL,
  `anio` int(11) DEFAULT NULL,
  `transmision` int(11) DEFAULT NULL,
  `km` varchar(45) DEFAULT NULL,
  `tipoVehiculo` int(11) DEFAULT NULL,
  `modeloVehiculo` int(11) DEFAULT NULL,
  `version` varchar(45) DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  `placa` varchar(45) DEFAULT NULL,
  `motor` varchar(45) DEFAULT NULL,
  `cilindros` varchar(45) DEFAULT NULL,
  `traccion` varchar(45) DEFAULT NULL,
  `vidriosAhumados` tinyint(1) DEFAULT NULL,
  `tapizado` tinyint(1) DEFAULT NULL,
  `airbag` tinyint(1) DEFAULT NULL,
  `frenosAbs` tinyint(1) DEFAULT NULL,
  `aireAcondicionado` tinyint(1) DEFAULT NULL,
  `estereo` tinyint(1) DEFAULT NULL,
  `direccionVehiculo` int(11) DEFAULT NULL,
  `precioVehiculo` int(11) DEFAULT NULL,
  `negociable` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idCarro`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `carros`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carros_has_imagenescarros`
--

CREATE TABLE IF NOT EXISTS `carros_has_imagenescarros` (
  `carros_idCarro` int(11) NOT NULL,
  `ImagenesCarros_idImagenesCarros` int(11) NOT NULL,
  PRIMARY KEY (`carros_idCarro`,`ImagenesCarros_idImagenesCarros`),
  KEY `ImagenesCarros_idImagenesCarros` (`ImagenesCarros_idImagenesCarros`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `carros_has_imagenescarros`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ciudad`
--

CREATE TABLE IF NOT EXISTS `ciudad` (
  `idciudad` int(11) NOT NULL AUTO_INCREMENT,
  `ciudad` varchar(45) NOT NULL,
  `Estado_idEstado` int(11) NOT NULL,
  PRIMARY KEY (`idciudad`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `ciudad`
--

INSERT INTO `ciudad` (`idciudad`, `ciudad`, `Estado_idEstado`) VALUES
(1, 'Los teques', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `concesionarios`
--

CREATE TABLE IF NOT EXISTS `concesionarios` (
  `idconcesionarios` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `email` varchar(200) NOT NULL,
  `productos_y_servicios` varchar(500) DEFAULT NULL,
  `contacto` varchar(500) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `Estado_idEstado` int(11) NOT NULL,
  `ciudad_idciudad` int(11) NOT NULL,
  PRIMARY KEY (`idconcesionarios`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `concesionarios`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `concesionarios_has_carros`
--

CREATE TABLE IF NOT EXISTS `concesionarios_has_carros` (
  `concesionarios_idconcesionarios` int(11) NOT NULL,
  `carros_idCarro` int(11) NOT NULL,
  PRIMARY KEY (`concesionarios_idconcesionarios`,`carros_idCarro`),
  KEY `carros_idCarro` (`carros_idCarro`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `concesionarios_has_carros`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direccionvehiculo`
--

CREATE TABLE IF NOT EXISTS `direccionvehiculo` (
  `iddireccionVehiculo` int(11) NOT NULL AUTO_INCREMENT,
  `direccionVehiculo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`iddireccionVehiculo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `direccionvehiculo`
--

INSERT INTO `direccionvehiculo` (`iddireccionVehiculo`, `direccionVehiculo`) VALUES
(1, 'Hidromática'),
(2, 'Mecánica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE IF NOT EXISTS `estado` (
  `idEstado` int(11) NOT NULL AUTO_INCREMENT,
  `Estado` varchar(45) NOT NULL,
  PRIMARY KEY (`idEstado`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `estado`
--

INSERT INTO `estado` (`idEstado`, `Estado`) VALUES
(1, 'Miranda');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenescarros`
--

CREATE TABLE IF NOT EXISTS `imagenescarros` (
  `idImagenesCarros` int(11) NOT NULL AUTO_INCREMENT,
  `urlImagen` varchar(1000) NOT NULL,
  `titulo` varchar(60) NOT NULL,
  `tipoimagen_idtipoimagen` int(11) NOT NULL,
  PRIMARY KEY (`idImagenesCarros`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `imagenescarros`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `local`
--

CREATE TABLE IF NOT EXISTS `local` (
  `idlocal` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(200) NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  `localcol` varchar(45) DEFAULT NULL,
  `Estado_idEstado` int(11) NOT NULL,
  `ciudad_idciudad` int(11) NOT NULL,
  `servicio_idservicio` int(11) NOT NULL,
  `vinculo1` varchar(100) DEFAULT NULL,
  `vinculo2` varchar(100) DEFAULT NULL,
  `vinculo3` varchar(100) DEFAULT NULL,
  `vinculo4` varchar(100) DEFAULT NULL,
  `HTML1` longblob,
  `HTML2` longblob,
  `HTML3` longblob,
  `HTML4` longblob,
  `localcol1` varchar(45) DEFAULT NULL,
  `direccion` varchar(500) DEFAULT NULL,
  `telefono1` varchar(40) DEFAULT NULL,
  `telefono2` varchar(40) DEFAULT NULL,
  `fax1` varchar(40) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `web` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`idlocal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `local`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marcas`
--

CREATE TABLE IF NOT EXISTS `marcas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL DEFAULT '0',
  `urlImagen` varchar(200) NOT NULL DEFAULT '0',
  `banner` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=60 ;

--
-- Volcar la base de datos para la tabla `marcas`
--

INSERT INTO `marcas` (`id`, `nombre`, `urlImagen`, `banner`) VALUES
(1, 'acura', 'acura.gif', 'ACURA-BANNER.JPG'),
(2, 'alfa-romeo', 'alfa-romeo.gif', 'ALFA-ROMEO-BANNER.JPG'),
(3, 'audi', 'audi.gif', 'AUDI-BANNER.JPG'),
(4, 'bmw', 'bmw.gif', 'BMW-BANNER.JPG'),
(5, 'buick', 'buick.gif', 'BUICK-BANNER.JPG'),
(6, 'byd', 'byd.gif', 'BYD-BANNER.JPG'),
(7, 'cadillac', 'cadillac.gif', 'CADILLAC-BANNER.JPG'),
(8, 'chana', 'chana.gif', 'CHANA-BANNER.JPG'),
(9, 'chery', 'chery.gif', 'CHERY-BANNER.JPG'),
(10, 'chevrolet', 'chevrolet.gif', 'CHEVROLET-BANNER.JPG'),
(11, 'chrysler', 'chrysler.gif', 'CHRYSLER-BANNER.JPG'),
(12, 'citroen', 'citroen.gif', 'CITROEN-BANNER.JPG'),
(13, 'corvette', 'corvette.gif', 'CORVETTE-BANNER.JPG'),
(14, 'daewoo', 'daewoo.gif', 'DAEWOO-BANNER.JPG'),
(15, 'dodge', 'dodge.gif', 'DODGE-BANNER.JPG'),
(16, 'ferrari', 'ferrari.gif', 'FERRARI-BANNER.JPG'),
(17, 'fiat', 'fiat.jpg', 'FIAT-BANNER.JPG'),
(18, 'ford', 'ford.gif', 'FORD-BANNER.JPG'),
(19, 'geely', 'geely.gif', 'GEELY-BANNER.JPG'),
(20, 'great-wall', 'great-wall.gif', 'GREAT-WALL-BANNER.JPG'),
(21, 'hafei', 'hafei.gif', 'HAFEI-BANNER.JPG'),
(22, 'haima', 'haima.gif', 'HAIMA-BANNER.JPG'),
(23, 'honda', 'honda.gif', 'HONDA-BANNER.JPG'),
(24, 'hummer', 'hummer.gif', 'HUMMER-BANNER.JPG'),
(25, 'hyundai', 'hyundai.gif', 'HYUNDAI-BANNER.JPG'),
(26, 'infinity', 'infinity.gif', 'INFINITY-BANNER.JPG'),
(27, 'isuzu', 'isuzu.gif', 'ISUZU-BANNER.JPG'),
(28, 'jaguar', 'jaguar.gif', 'JAGUAR-BANNER.JPG'),
(29, 'jeep', 'jeep.gif', 'JEEP-BANNER.JPG'),
(30, 'jmc', 'jmc.gif', 'JMC-BANNER.JPG'),
(31, 'kia', 'kia.gif', 'KIA-BANNER.JPG'),
(32, 'lada', 'lada.gif', 'LADA-BANNER.JPG'),
(33, 'land-rover', 'land-rover.gif', 'LAND-ROVER-BANNER.JPG'),
(34, 'lexus', 'lexus.gif', 'LEXUS-BANNER.JPG'),
(35, 'lifan', 'lifan.gif', 'LIFAN-BANNER.JPG'),
(36, 'lincoln', 'lincoln.gif', 'LINCOLN-BANNER.JPG'),
(37, 'maserati', 'maserati.gif', 'MASERATI-BANNER.JPG'),
(38, 'mazda', 'mazda.gif', 'MAZDA-BANNER.JPG'),
(39, 'mercedes', 'mercedes.gif', 'MERCEDES-BANNER.JPG'),
(40, 'mercury', 'mercury.gif', 'MERCURY-BANNER.JPG'),
(41, 'mini', 'mini.gif', 'MINI-BANNER.JPG'),
(42, 'mitsubishi', 'mitsubishi.gif', 'MITSUBISHI-BANNER.JPG'),
(43, 'nissan', 'nissan.gif', 'NISSAN-BANNER.JPG'),
(44, 'peugeot', 'peugeot.gif', 'PEUGEOT-BANNER.JPG'),
(45, 'pontiac', 'pontiac.gif', 'PONTIAC-BANNER.JPG'),
(46, 'porsche', 'porsche.gif', 'PORSCHE-BANNER.JPG'),
(47, 'renault', 'renault.gif', 'RENAULT-BANNER.JPG'),
(48, 'saic-wuling', 'saic-wuling.gif', 'SAIC-WULING-BANNER.JPG'),
(49, 'scion', 'scion.gif', 'SCION-BANNER.JPG'),
(50, 'seat', 'seat.gif', 'SEAT-BANNER.JPG'),
(51, 'skoda', 'skoda.gif', 'SKODA-BANNER.JPG'),
(52, 'smart', 'smart.gif', 'SMART-BANNER.JPG'),
(53, 'subaru', 'subaru.gif', 'SUBARU-BANNER.JPG'),
(54, 'tata', 'tata.gif', 'TATA-BANNER.JPG'),
(55, 'toyota', 'toyota.gif', 'TOYOTA-BANNER.JPG'),
(56, 'tyanye', 'tyanye.gif', 'TYANYE-BANNER.JPG'),
(57, 'volkswagen', 'volkswagen.gif', 'VOLKSWAGEN-BANNER.JPG'),
(58, 'zhongxing', 'zhongxing.gif', 'ZHONGXING-BANNER.JPG'),
(59, 'zotye', 'zotye', '-BANNER.JPG');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelos`
--

CREATE TABLE IF NOT EXISTS `modelos` (
  `idmodelos` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `idmarcas` int(11) DEFAULT NULL,
  PRIMARY KEY (`idmodelos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `modelos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelovehiculo`
--

CREATE TABLE IF NOT EXISTS `modelovehiculo` (
  `idmodelovehiculo` int(11) NOT NULL AUTO_INCREMENT,
  `modelovehiculo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idmodelovehiculo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `modelovehiculo`
--

INSERT INTO `modelovehiculo` (`idmodelovehiculo`, `modelovehiculo`) VALUES
(1, 'Automático'),
(2, 'Sincrónico');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicaciones`
--

CREATE TABLE IF NOT EXISTS `publicaciones` (
  `idpublicaciones` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(140) NOT NULL,
  `urlDestino` varchar(1000) NOT NULL,
  `urlImagen` varchar(1000) NOT NULL,
  `vecesVisto` int(11) DEFAULT '0',
  `vecesClick` int(11) DEFAULT '0',
  PRIMARY KEY (`idpublicaciones`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `publicaciones`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio`
--

CREATE TABLE IF NOT EXISTS `servicio` (
  `idservicio` int(11) NOT NULL AUTO_INCREMENT,
  `servicio` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idservicio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `servicio`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipoimagen`
--

CREATE TABLE IF NOT EXISTS `tipoimagen` (
  `idtipoimagen` int(11) NOT NULL AUTO_INCREMENT,
  `tipoimagen` varchar(45) NOT NULL,
  PRIMARY KEY (`idtipoimagen`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `tipoimagen`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipousuario`
--

CREATE TABLE IF NOT EXISTS `tipousuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `tipousuario`
--

INSERT INTO `tipousuario` (`id`, `nombre`) VALUES
(1, 'Admin'),
(2, 'Usuario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipovehiculo`
--

CREATE TABLE IF NOT EXISTS `tipovehiculo` (
  `idtipovehiculo` int(11) NOT NULL AUTO_INCREMENT,
  `tipovehiculo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idtipovehiculo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `tipovehiculo`
--

INSERT INTO `tipovehiculo` (`idtipovehiculo`, `tipovehiculo`) VALUES
(1, 'Sedan'),
(2, 'Coupe');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `traccionvehiculo`
--

CREATE TABLE IF NOT EXISTS `traccionvehiculo` (
  `idtraccionvehiculo` int(11) NOT NULL AUTO_INCREMENT,
  `traccionvehiculo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idtraccionvehiculo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `traccionvehiculo`
--

INSERT INTO `traccionvehiculo` (`idtraccionvehiculo`, `traccionvehiculo`) VALUES
(1, 'normal'),
(2, '4x4');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transmisionvehiculo`
--

CREATE TABLE IF NOT EXISTS `transmisionvehiculo` (
  `idtransmisionvehiculo` int(11) NOT NULL AUTO_INCREMENT,
  `transmisionvehiculo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idtransmisionvehiculo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `transmisionvehiculo`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `idusuarios` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `apellido` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `fechacreacion` date NOT NULL DEFAULT '1000-01-01',
  `cedularif` varchar(45) NOT NULL,
  `telefono1` varchar(45) NOT NULL,
  `telefono2` varchar(45) DEFAULT NULL,
  `direccion` varchar(200) NOT NULL,
  `Estado_idEstado` int(11) NOT NULL,
  `ciudad_idciudad` int(11) NOT NULL,
  `tipousuario` int(11) NOT NULL,
  PRIMARY KEY (`idusuarios`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idusuarios`, `nombre`, `apellido`, `login`, `password`, `fechacreacion`, `cedularif`, `telefono1`, `telefono2`, `direccion`, `Estado_idEstado`, `ciudad_idciudad`, `tipousuario`) VALUES
(5, 'Anyul', 'Rivas', 'anyulled', 'alrorecg', '2010-07-25', '15913233', '04267174942', '02123649248', 'simon bolivar', 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_has_carros`
--

CREATE TABLE IF NOT EXISTS `usuarios_has_carros` (
  `usuarios_idusuarios` int(11) NOT NULL,
  `carros_idcarros` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`usuarios_idusuarios`,`carros_idcarros`),
  KEY `carros_idcarros` (`carros_idcarros`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `usuarios_has_carros`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_has_concesionarios`
--

CREATE TABLE IF NOT EXISTS `usuarios_has_concesionarios` (
  `usuarios_idusuarios` int(11) NOT NULL,
  `concesionarios_idconcesionarios` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`usuarios_idusuarios`,`concesionarios_idconcesionarios`),
  KEY `concesionarios_idconcesionarios` (`concesionarios_idconcesionarios`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `usuarios_has_concesionarios`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_has_local`
--

CREATE TABLE IF NOT EXISTS `usuarios_has_local` (
  `usuarios_idusuarios` int(11) NOT NULL,
  `local_idlocal` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`usuarios_idusuarios`,`local_idlocal`),
  KEY `local_idlocal` (`local_idlocal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `usuarios_has_local`
--


--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `carros`
--
ALTER TABLE `carros`
  ADD CONSTRAINT `carros_FK_1` FOREIGN KEY (`idCarro`) REFERENCES `carros_has_imagenescarros` (`carros_idCarro`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `carros_has_imagenescarros`
--
ALTER TABLE `carros_has_imagenescarros`
  ADD CONSTRAINT `carros_has_imagenescarros_FK_1` FOREIGN KEY (`ImagenesCarros_idImagenesCarros`) REFERENCES `imagenescarros` (`idImagenesCarros`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `concesionarios`
--
ALTER TABLE `concesionarios`
  ADD CONSTRAINT `concesionarios_FK_1` FOREIGN KEY (`idconcesionarios`) REFERENCES `concesionarios_has_carros` (`concesionarios_idconcesionarios`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `concesionarios_has_carros`
--
ALTER TABLE `concesionarios_has_carros`
  ADD CONSTRAINT `concesionarios_has_carros_FK_1` FOREIGN KEY (`carros_idCarro`) REFERENCES `carros` (`idCarro`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios_has_carros`
--
ALTER TABLE `usuarios_has_carros`
  ADD CONSTRAINT `usuarios_has_carros_FK_1` FOREIGN KEY (`usuarios_idusuarios`) REFERENCES `usuarios` (`idusuarios`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usuarios_has_carros_FK_2` FOREIGN KEY (`carros_idcarros`) REFERENCES `carros` (`idCarro`);

--
-- Filtros para la tabla `usuarios_has_local`
--
ALTER TABLE `usuarios_has_local`
  ADD CONSTRAINT `usuarios_has_local_FK_1` FOREIGN KEY (`usuarios_idusuarios`) REFERENCES `usuarios` (`idusuarios`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usuarios_has_local_FK_2` FOREIGN KEY (`local_idlocal`) REFERENCES `local` (`idlocal`);
