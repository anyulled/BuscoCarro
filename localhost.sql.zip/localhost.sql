-- phpMyAdmin SQL Dump
-- version 3.3.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 04-05-2010 a las 13:57:14
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.2-1ubuntu4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `buscocarro`
--
CREATE DATABASE `buscocarro` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `buscocarro`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carros`
--

CREATE TABLE IF NOT EXISTS `carros` (
  `idCarro` int(11) NOT NULL,
  `idMarca` int(11) DEFAULT NULL,
  `idModelo` int(11) DEFAULT NULL,
  `anio` int(11) DEFAULT NULL,
  `transmision` int(11) DEFAULT NULL,
  `km` varchar(45) DEFAULT NULL,
  `tipoVehiculo` int(11) DEFAULT NULL,
  `modeloVehiculo` int(11) DEFAULT NULL,
  `version` varchar(45) DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  `placa` varchar(45) DEFAULT NULL,
  `motor` varchar(45) DEFAULT NULL,
  `cilindros` varchar(45) DEFAULT NULL,
  `traccion` varchar(45) DEFAULT NULL,
  `vidriosAhumados` tinyint(1) DEFAULT NULL,
  `tapizado` tinyint(1) DEFAULT NULL,
  `airbag` tinyint(1) DEFAULT NULL,
  `frenosAbs` tinyint(1) DEFAULT NULL,
  `aireAcondicionado` tinyint(1) DEFAULT NULL,
  `estereo` tinyint(1) DEFAULT NULL,
  `direccionVehiculo` int(11) DEFAULT NULL,
  `precioVehiculo` int(11) DEFAULT NULL,
  `negociable` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idCarro`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `carros`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carros_has_imagenescarros`
--

CREATE TABLE IF NOT EXISTS `carros_has_imagenescarros` (
  `carros_idCarro` int(11) NOT NULL,
  `ImagenesCarros_idImagenesCarros` int(11) NOT NULL,
  PRIMARY KEY (`carros_idCarro`,`ImagenesCarros_idImagenesCarros`),
  KEY `ImagenesCarros_idImagenesCarros` (`ImagenesCarros_idImagenesCarros`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `carros_has_imagenescarros`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ciudad`
--

CREATE TABLE IF NOT EXISTS `ciudad` (
  `idciudad` int(11) NOT NULL,
  `ciudad` varchar(45) NOT NULL,
  `Estado_idEstado` int(11) NOT NULL,
  PRIMARY KEY (`idciudad`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `ciudad`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `concesionarios`
--

CREATE TABLE IF NOT EXISTS `concesionarios` (
  `idconcesionarios` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `email` varchar(200) NOT NULL,
  `productos_y_servicios` varchar(500) DEFAULT NULL,
  `contacto` varchar(500) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `Estado_idEstado` int(11) NOT NULL,
  `ciudad_idciudad` int(11) NOT NULL,
  PRIMARY KEY (`idconcesionarios`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `concesionarios`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `concesionarios_has_carros`
--

CREATE TABLE IF NOT EXISTS `concesionarios_has_carros` (
  `concesionarios_idconcesionarios` int(11) NOT NULL,
  `carros_idCarro` int(11) NOT NULL,
  PRIMARY KEY (`concesionarios_idconcesionarios`,`carros_idCarro`),
  KEY `carros_idCarro` (`carros_idCarro`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `concesionarios_has_carros`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direccionvehiculo`
--

CREATE TABLE IF NOT EXISTS `direccionvehiculo` (
  `iddireccionVehiculo` int(11) NOT NULL,
  `direccionVehiculo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`iddireccionVehiculo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `direccionvehiculo`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE IF NOT EXISTS `estado` (
  `idEstado` int(11) NOT NULL,
  `Estado` varchar(45) NOT NULL,
  PRIMARY KEY (`idEstado`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `estado`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenescarros`
--

CREATE TABLE IF NOT EXISTS `imagenescarros` (
  `idImagenesCarros` int(11) NOT NULL,
  `urlImagen` varchar(1000) NOT NULL,
  `titulo` varchar(60) NOT NULL,
  `tipoimagen_idtipoimagen` int(11) NOT NULL,
  PRIMARY KEY (`idImagenesCarros`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `imagenescarros`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `local`
--

CREATE TABLE IF NOT EXISTS `local` (
  `idlocal` int(11) NOT NULL,
  `Nombre` varchar(200) NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  `localcol` varchar(45) DEFAULT NULL,
  `Estado_idEstado` int(11) NOT NULL,
  `ciudad_idciudad` int(11) NOT NULL,
  `servicio_idservicio` int(11) NOT NULL,
  `vinculo1` varchar(100) DEFAULT NULL,
  `vinculo2` varchar(100) DEFAULT NULL,
  `vinculo3` varchar(100) DEFAULT NULL,
  `vinculo4` varchar(100) DEFAULT NULL,
  `HTML1` longblob,
  `HTML2` longblob,
  `HTML3` longblob,
  `HTML4` longblob,
  `localcol1` varchar(45) DEFAULT NULL,
  `direccion` varchar(500) DEFAULT NULL,
  `telefono1` varchar(40) DEFAULT NULL,
  `telefono2` varchar(40) DEFAULT NULL,
  `fax1` varchar(40) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `web` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`idlocal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `local`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marcas`
--

CREATE TABLE IF NOT EXISTS `marcas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL DEFAULT '0',
  `urlImagen` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `marcas`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelos`
--

CREATE TABLE IF NOT EXISTS `modelos` (
  `idmodelos` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `idmarcas` int(11) DEFAULT NULL,
  PRIMARY KEY (`idmodelos`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `modelos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelovehiculo`
--

CREATE TABLE IF NOT EXISTS `modelovehiculo` (
  `idmodelovehiculo` int(11) NOT NULL,
  `modelovehiculo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idmodelovehiculo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `modelovehiculo`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicaciones`
--

CREATE TABLE IF NOT EXISTS `publicaciones` (
  `idpublicaciones` int(11) NOT NULL,
  `titulo` varchar(140) NOT NULL,
  `urlDestino` varchar(1000) NOT NULL,
  `urlImagen` varchar(1000) NOT NULL,
  `vecesVisto` int(11) DEFAULT '0',
  `vecesClick` int(11) DEFAULT '0',
  PRIMARY KEY (`idpublicaciones`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `publicaciones`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio`
--

CREATE TABLE IF NOT EXISTS `servicio` (
  `idservicio` int(11) NOT NULL,
  `servicio` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idservicio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `servicio`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipoimagen`
--

CREATE TABLE IF NOT EXISTS `tipoimagen` (
  `idtipoimagen` int(11) NOT NULL,
  `tipoimagen` varchar(45) NOT NULL,
  PRIMARY KEY (`idtipoimagen`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `tipoimagen`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipovehiculo`
--

CREATE TABLE IF NOT EXISTS `tipovehiculo` (
  `idtipovehiculo` int(11) NOT NULL,
  `tipovehiculo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idtipovehiculo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `tipovehiculo`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `traccionvehiculo`
--

CREATE TABLE IF NOT EXISTS `traccionvehiculo` (
  `idtraccionvehiculo` int(11) NOT NULL,
  `traccionvehiculo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idtraccionvehiculo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `traccionvehiculo`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transmisionvehiculo`
--

CREATE TABLE IF NOT EXISTS `transmisionvehiculo` (
  `idtransmisionvehiculo` int(11) NOT NULL,
  `transmisionvehiculo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idtransmisionvehiculo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `transmisionvehiculo`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `idusuarios` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellido` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `fechacreacion` date NOT NULL DEFAULT '1000-01-01',
  `cedularif` varchar(45) NOT NULL,
  `telefono1` varchar(45) NOT NULL,
  `telefono2` varchar(45) DEFAULT NULL,
  `direccion` varchar(200) NOT NULL,
  `Estado_idEstado` int(11) NOT NULL,
  `ciudad_idciudad` int(11) NOT NULL,
  PRIMARY KEY (`idusuarios`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `usuarios`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_has_carros`
--

CREATE TABLE IF NOT EXISTS `usuarios_has_carros` (
  `usuarios_idusuarios` int(11) NOT NULL,
  `carros_idcarros` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`usuarios_idusuarios`,`carros_idcarros`),
  KEY `carros_idcarros` (`carros_idcarros`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `usuarios_has_carros`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_has_concesionarios`
--

CREATE TABLE IF NOT EXISTS `usuarios_has_concesionarios` (
  `usuarios_idusuarios` int(11) NOT NULL,
  `concesionarios_idconcesionarios` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`usuarios_idusuarios`,`concesionarios_idconcesionarios`),
  KEY `concesionarios_idconcesionarios` (`concesionarios_idconcesionarios`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `usuarios_has_concesionarios`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_has_local`
--

CREATE TABLE IF NOT EXISTS `usuarios_has_local` (
  `usuarios_idusuarios` int(11) NOT NULL,
  `local_idlocal` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`usuarios_idusuarios`,`local_idlocal`),
  KEY `local_idlocal` (`local_idlocal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `usuarios_has_local`
--


--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `carros`
--
ALTER TABLE `carros`
  ADD CONSTRAINT `carros_FK_1` FOREIGN KEY (`idCarro`) REFERENCES `carros_has_imagenescarros` (`carros_idCarro`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `carros_has_imagenescarros`
--
ALTER TABLE `carros_has_imagenescarros`
  ADD CONSTRAINT `carros_has_imagenescarros_FK_1` FOREIGN KEY (`ImagenesCarros_idImagenesCarros`) REFERENCES `imagenescarros` (`idImagenesCarros`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `concesionarios`
--
ALTER TABLE `concesionarios`
  ADD CONSTRAINT `concesionarios_FK_1` FOREIGN KEY (`idconcesionarios`) REFERENCES `concesionarios_has_carros` (`concesionarios_idconcesionarios`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `concesionarios_has_carros`
--
ALTER TABLE `concesionarios_has_carros`
  ADD CONSTRAINT `concesionarios_has_carros_FK_1` FOREIGN KEY (`carros_idCarro`) REFERENCES `carros` (`idCarro`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`idusuarios`) REFERENCES `usuarios_has_concesionarios` (`usuarios_idusuarios`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `usuarios_has_carros`
--
ALTER TABLE `usuarios_has_carros`
  ADD CONSTRAINT `usuarios_has_carros_FK_1` FOREIGN KEY (`usuarios_idusuarios`) REFERENCES `usuarios` (`idusuarios`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usuarios_has_carros_FK_2` FOREIGN KEY (`carros_idcarros`) REFERENCES `carros` (`idCarro`);

--
-- Filtros para la tabla `usuarios_has_concesionarios`
--
ALTER TABLE `usuarios_has_concesionarios`
  ADD CONSTRAINT `usuarios_has_concesionarios_FK_1` FOREIGN KEY (`concesionarios_idconcesionarios`) REFERENCES `concesionarios` (`idconcesionarios`);

--
-- Filtros para la tabla `usuarios_has_local`
--
ALTER TABLE `usuarios_has_local`
  ADD CONSTRAINT `usuarios_has_local_FK_1` FOREIGN KEY (`usuarios_idusuarios`) REFERENCES `usuarios` (`idusuarios`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usuarios_has_local_FK_2` FOREIGN KEY (`local_idlocal`) REFERENCES `local` (`idlocal`);
